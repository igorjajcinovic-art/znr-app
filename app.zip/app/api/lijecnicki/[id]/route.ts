import { prisma } from "@/lib/prisma";

export async function PUT(
  req: Request,
  { params }: { params: { id: string } }
) {
  const body = await req.json();

  const pregled = await prisma.lijecnickiPregled.update({
    where: { id: params.id },
    data: {
      oib: body.oib,
      vrsta: body.vrsta || null,
      datum: new Date(body.datum),
      vrijediDo: new Date(body.vrijediDo),
      napomena: body.napomena || null,
    },
  });

  return Response.json(pregled);
}

export async function DELETE(
  _req: Request,
  { params }: { params: { id: string } }
) {
  await prisma.lijecnickiPregled.delete({
    where: { id: params.id },
  });

  return Response.json({ ok: true });
}