import { prisma } from "@/lib/prisma";

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const firmaId = searchParams.get("firmaId");

  const pregledi = await prisma.lijecnickiPregled.findMany({
    where: firmaId ? { firmaId } : undefined,
    orderBy: { datum: "desc" },
  });

  return Response.json(pregledi);
}

export async function POST(req: Request) {
  const body = await req.json();

  const pregled = await prisma.lijecnickiPregled.create({
    data: {
      firmaId: body.firmaId,
      oib: body.oib,
      vrsta: body.vrsta || null,
      datum: new Date(body.datum),
      vrijediDo: new Date(body.vrijediDo),
      napomena: body.napomena || null,
    },
  });

  return Response.json(pregled, { status: 201 });
}