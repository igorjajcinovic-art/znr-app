"use client";

import Link from "next/link";
import { useEffect, useRef, useState } from "react";

type Tvrtka = {
  id: string;
  naziv: string;
  oib: string;
  adresa: string | null;
};

type FormaTvrtka = {
  naziv: string;
  oib: string;
  adresa: string;
};

const praznaTvrtka: FormaTvrtka = {
  naziv: "",
  oib: "",
  adresa: "",
};

export default function TvrtkePage() {
  const [tvrtke, setTvrtke] = useState<Tvrtka[]>([]);
  const [forma, setForma] = useState<FormaTvrtka>(praznaTvrtka);
  const [ucitavanje, setUcitavanje] = useState(true);
  const [spremanje, setSpremanje] = useState(false);
  const [greska, setGreska] = useState("");
  const [editId, setEditId] = useState<string | null>(null);
  const [backupFile, setBackupFile] = useState<File | null>(null);
  const [restoreLoading, setRestoreLoading] = useState(false);

  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const ucitajTvrtke = async () => {
    try {
      setGreska("");
      setUcitavanje(true);

      const res = await fetch("/api/tvrtke", {
        method: "GET",
        cache: "no-store",
      });

      if (!res.ok) {
        const text = await res.text();
        throw new Error(text || "Ne mogu učitati tvrtke.");
      }

      const data: Tvrtka[] = await res.json();
      setTvrtke(Array.isArray(data) ? data : []);
    } catch (err) {
      setGreska(err instanceof Error ? err.message : "Greška pri učitavanju.");
      setTvrtke([]);
    } finally {
      setUcitavanje(false);
    }
  };

  useEffect(() => {
    ucitajTvrtke();
  }, []);

  const spremiTvrtku = async () => {
    if (!forma.naziv.trim() || !forma.oib.trim()) {
      alert("Unesi naziv i OIB tvrtke.");
      return;
    }

    try {
      setSpremanje(true);
      setGreska("");

      const res = await fetch(
        editId ? `/api/tvrtke/${editId}` : "/api/tvrtke",
        {
          method: editId ? "PUT" : "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            naziv: forma.naziv.trim(),
            oib: forma.oib.trim(),
            adresa: forma.adresa.trim() || null,
          }),
        }
      );

      if (!res.ok) {
        const text = await res.text();
        throw new Error(text || "Ne mogu spremiti tvrtku.");
      }

      setForma(praznaTvrtka);
      setEditId(null);
      await ucitajTvrtke();
    } catch (err) {
      setGreska(err instanceof Error ? err.message : "Greška pri spremanju.");
    } finally {
      setSpremanje(false);
    }
  };

  const pokreniUredenje = (tvrtka: Tvrtka) => {
    setForma({
      naziv: tvrtka.naziv,
      oib: tvrtka.oib,
      adresa: tvrtka.adresa || "",
    });
    setEditId(tvrtka.id);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const odustani = () => {
    setForma(praznaTvrtka);
    setEditId(null);
  };

  const obrisiTvrtku = async (id: string, naziv: string) => {
    const potvrda = confirm(
      `Obrisati tvrtku "${naziv}"?\n\nObrisat će se i povezani podaci.`
    );

    if (!potvrda) return;

    try {
      setGreska("");

      const res = await fetch(`/api/tvrtke/${id}`, {
        method: "DELETE",
      });

      if (!res.ok) {
        const text = await res.text();
        throw new Error(text || "Ne mogu obrisati tvrtku.");
      }

      if (editId === id) {
        odustani();
      }

      await ucitajTvrtke();
    } catch (err) {
      setGreska(err instanceof Error ? err.message : "Greška pri brisanju.");
    }
  };

  const preuzmiBackup = async () => {
    try {
      setGreska("");

      const res = await fetch("/api/backup");
      if (!res.ok) {
        throw new Error("Ne mogu preuzeti backup.");
      }

      const data = await res.json();

      const blob = new Blob([JSON.stringify(data, null, 2)], {
        type: "application/json",
      });

      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "backup.json";
      a.click();
      URL.revokeObjectURL(url);
    } catch (err) {
      setGreska(err instanceof Error ? err.message : "Greška kod backupa.");
    }
  };

  const vratiBackup = async () => {
    if (!backupFile) {
      alert("Prvo odaberi backup.json file.");
      return;
    }

    const potvrda = confirm(
      "Jesi siguran da želiš vratiti backup?\n\nPostojeći podaci bit će zamijenjeni."
    );

    if (!potvrda) return;

    try {
      setRestoreLoading(true);
      setGreska("");

      const text = await backupFile.text();
      const json = JSON.parse(text);

      const res = await fetch("/api/restore", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(json),
      });

      if (!res.ok) {
        const errText = await res.text();
        throw new Error(errText || "Ne mogu vratiti backup.");
      }

      alert("Backup je uspješno vraćen.");

      setBackupFile(null);
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }

      setForma(praznaTvrtka);
      setEditId(null);
      await ucitajTvrtke();
    } catch (err) {
      setGreska(
        err instanceof Error ? err.message : "Greška kod vraćanja backupa."
      );
    } finally {
      setRestoreLoading(false);
    }
  };

  return (
    <div style={pageStyle}>
      <div style={containerStyle}>
        <div style={heroStyle}>
          <div style={heroTopStyle}>
            <div>
              <div style={heroBadgeStyle}>ZNR aplikacija</div>
              <h1 style={heroTitleStyle}>Tvrtke</h1>
              <p style={heroTextStyle}>
                Upravljaj tvrtkama, radnicima, liječničkim pregledima,
                osposobljavanjima, opremom, ispisima i upozorenjima.
              </p>
            </div>

            <div style={heroInfoCardStyle}>
              <div style={heroInfoLabelStyle}>Ukupno tvrtki</div>
              <div style={heroInfoValueStyle}>{tvrtke.length}</div>
            </div>
          </div>

          <div style={heroActionsStyle}>
            <button style={blueButtonStyle} onClick={preuzmiBackup}>
              Preuzmi backup
            </button>

            <Link href="/upozorenja" style={darkLinkStyle}>
              Upozorenja
            </Link>

            <Link href="/radnici/povijest" style={darkLinkStyle}>
              Povijest radnika
            </Link>
          </div>
        </div>

        <div style={cardStyle}>
          <h2 style={sectionTitleStyle}>Backup i vraćanje podataka</h2>

          <div
            style={{
              display: "grid",
              gridTemplateColumns: "2fr 1fr",
              gap: 16,
              alignItems: "end",
            }}
          >
            <div>
              <label style={labelStyle}>Odaberi backup.json</label>
              <input
                ref={fileInputRef}
                type="file"
                accept=".json,application/json"
                style={inputStyle}
                onChange={(e) => {
                  const file = e.target.files?.[0] || null;
                  setBackupFile(file);
                }}
              />
            </div>

            <div>
              <button
                style={redButtonStyle}
                onClick={vratiBackup}
                disabled={restoreLoading}
              >
                {restoreLoading ? "Vraćanje..." : "Vrati backup"}
              </button>
            </div>
          </div>

          {backupFile && (
            <div style={{ marginTop: 12, color: "#374151" }}>
              Odabrani file: <strong>{backupFile.name}</strong>
            </div>
          )}
        </div>

        <div style={cardStyle}>
          <h2 style={sectionTitleStyle}>
            {editId ? "Uređenje tvrtke" : "Dodavanje tvrtke"}
          </h2>

          <div style={formGridStyle}>
            <div>
              <label style={labelStyle}>Naziv tvrtke</label>
              <input
                style={inputStyle}
                value={forma.naziv}
                onChange={(e) =>
                  setForma({ ...forma, naziv: e.target.value })
                }
                placeholder="Naziv tvrtke"
              />
            </div>

            <div>
              <label style={labelStyle}>OIB</label>
              <input
                style={inputStyle}
                value={forma.oib}
                onChange={(e) => setForma({ ...forma, oib: e.target.value })}
                placeholder="OIB"
              />
            </div>

            <div>
              <label style={labelStyle}>Adresa</label>
              <input
                style={inputStyle}
                value={forma.adresa}
                onChange={(e) =>
                  setForma({ ...forma, adresa: e.target.value })
                }
                placeholder="Adresa"
              />
            </div>
          </div>

          <div style={actionRowStyle}>
            <button
              style={blackButtonStyle}
              onClick={spremiTvrtku}
              disabled={spremanje}
            >
              {spremanje
                ? "Spremanje..."
                : editId
                ? "Spremi izmjene"
                : "Dodaj tvrtku"}
            </button>

            {editId && (
              <button style={grayButtonStyle} onClick={odustani}>
                Odustani
              </button>
            )}

            <button
              style={lightButtonStyle}
              onClick={ucitajTvrtke}
              disabled={ucitavanje}
            >
              Osvježi
            </button>
          </div>

          {greska && <div style={errorBoxStyle}>{greska}</div>}
        </div>

        <div style={sectionHeaderStyle}>
          <h2 style={sectionTitleStyle}>Popis tvrtki</h2>
          <div style={sectionSubtitleStyle}>
            Otvori tvrtku i nastavi raditi po modulima.
          </div>
        </div>

        {ucitavanje ? (
          <div style={cardStyle}>Učitavanje...</div>
        ) : tvrtke.length === 0 ? (
          <div style={cardStyle}>Nema unesenih tvrtki.</div>
        ) : (
          <div style={tvrtkeGridStyle}>
            {tvrtke.map((t) => (
              <div key={t.id} style={tvrtkaCardStyle}>
                <div style={tvrtkaCardTopStyle}>
                  <div style={tvrtkaPillStyle}>Tvrtka</div>
                  <h3 style={tvrtkaTitleStyle}>{t.naziv}</h3>
                </div>

                <div style={tvrtkaMetaStyle}>
                  <div>
                    <strong>OIB:</strong> {t.oib}
                  </div>
                  <div>
                    <strong>Adresa:</strong> {t.adresa || "-"}
                  </div>
                </div>

                <div style={tvrtkaActionsStyle}>
                  <Link href={`/tvrtke/${t.id}`} style={darkLinkStyle}>
                    Otvori
                  </Link>

                  <button
                    style={smallGrayButtonStyle}
                    onClick={() => pokreniUredenje(t)}
                  >
                    Uredi
                  </button>

                  <button
                    style={smallRedButtonStyle}
                    onClick={() => obrisiTvrtku(t.id, t.naziv)}
                  >
                    Obriši
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

const pageStyle: React.CSSProperties = {
  background: "#f3f4f6",
  minHeight: "100vh",
  padding: 24,
};

const containerStyle: React.CSSProperties = {
  maxWidth: 1280,
  margin: "0 auto",
};

const heroStyle: React.CSSProperties = {
  background: "white",
  borderRadius: 22,
  boxShadow: "0 2px 12px rgba(0,0,0,0.08)",
  padding: 28,
  marginBottom: 24,
};

const heroTopStyle: React.CSSProperties = {
  display: "flex",
  justifyContent: "space-between",
  gap: 20,
  alignItems: "flex-start",
  flexWrap: "wrap",
  marginBottom: 20,
};

const heroBadgeStyle: React.CSSProperties = {
  display: "inline-block",
  padding: "6px 10px",
  borderRadius: 999,
  background: "#e5e7eb",
  color: "#111827",
  fontSize: 12,
  fontWeight: 700,
  marginBottom: 12,
};

const heroTitleStyle: React.CSSProperties = {
  fontSize: 38,
  fontWeight: 800,
  margin: 0,
  marginBottom: 10,
  color: "#111827",
};

const heroTextStyle: React.CSSProperties = {
  fontSize: 15,
  color: "#4b5563",
  lineHeight: 1.6,
  maxWidth: 720,
  margin: 0,
};

const heroInfoCardStyle: React.CSSProperties = {
  minWidth: 180,
  background: "#111827",
  color: "white",
  borderRadius: 18,
  padding: 18,
};

const heroInfoLabelStyle: React.CSSProperties = {
  fontSize: 13,
  opacity: 0.85,
  marginBottom: 8,
};

const heroInfoValueStyle: React.CSSProperties = {
  fontSize: 36,
  fontWeight: 800,
  lineHeight: 1,
};

const heroActionsStyle: React.CSSProperties = {
  display: "flex",
  gap: 10,
  flexWrap: "wrap",
};

const cardStyle: React.CSSProperties = {
  background: "white",
  borderRadius: 20,
  boxShadow: "0 2px 10px rgba(0,0,0,0.06)",
  padding: 24,
  marginBottom: 24,
};

const sectionHeaderStyle: React.CSSProperties = {
  marginBottom: 16,
};

const sectionTitleStyle: React.CSSProperties = {
  fontSize: 26,
  fontWeight: 800,
  margin: 0,
  marginBottom: 6,
  color: "#111827",
};

const sectionSubtitleStyle: React.CSSProperties = {
  color: "#6b7280",
  fontSize: 15,
};

const formGridStyle: React.CSSProperties = {
  display: "grid",
  gridTemplateColumns: "repeat(3, minmax(0, 1fr))",
  gap: 16,
};

const labelStyle: React.CSSProperties = {
  display: "block",
  marginBottom: 6,
  fontWeight: 600,
  fontSize: 14,
};

const inputStyle: React.CSSProperties = {
  width: "100%",
  padding: "11px 12px",
  border: "1px solid #cbd5e1",
  borderRadius: 10,
  fontSize: 14,
  boxSizing: "border-box",
};

const actionRowStyle: React.CSSProperties = {
  marginTop: 18,
  display: "flex",
  gap: 10,
  flexWrap: "wrap",
};

const blackButtonStyle: React.CSSProperties = {
  padding: "11px 16px",
  borderRadius: 10,
  border: "none",
  background: "#111827",
  color: "white",
  fontWeight: 700,
  cursor: "pointer",
};

const grayButtonStyle: React.CSSProperties = {
  padding: "11px 16px",
  borderRadius: 10,
  border: "none",
  background: "#9ca3af",
  color: "white",
  fontWeight: 700,
  cursor: "pointer",
};

const lightButtonStyle: React.CSSProperties = {
  padding: "11px 16px",
  borderRadius: 10,
  border: "none",
  background: "#e5e7eb",
  color: "#111827",
  fontWeight: 700,
  cursor: "pointer",
};

const blueButtonStyle: React.CSSProperties = {
  padding: "11px 16px",
  borderRadius: 10,
  border: "none",
  background: "#2563eb",
  color: "white",
  fontWeight: 700,
  cursor: "pointer",
};

const redButtonStyle: React.CSSProperties = {
  width: "100%",
  padding: "11px 16px",
  borderRadius: 10,
  border: "none",
  background: "#dc2626",
  color: "white",
  fontWeight: 700,
  cursor: "pointer",
};

const errorBoxStyle: React.CSSProperties = {
  marginTop: 14,
  padding: 10,
  borderRadius: 8,
  background: "#fee2e2",
  color: "#991b1b",
  border: "1px solid #f87171",
};

const tvrtkeGridStyle: React.CSSProperties = {
  display: "grid",
  gridTemplateColumns: "repeat(3, minmax(0, 1fr))",
  gap: 16,
};

const tvrtkaCardStyle: React.CSSProperties = {
  background: "white",
  borderRadius: 20,
  boxShadow: "0 2px 10px rgba(0,0,0,0.06)",
  padding: 22,
  display: "flex",
  flexDirection: "column",
  minHeight: 220,
};

const tvrtkaCardTopStyle: React.CSSProperties = {
  marginBottom: 16,
};

const tvrtkaPillStyle: React.CSSProperties = {
  display: "inline-block",
  padding: "6px 10px",
  borderRadius: 999,
  background: "#f3f4f6",
  color: "#111827",
  fontSize: 12,
  fontWeight: 700,
  marginBottom: 12,
};

const tvrtkaTitleStyle: React.CSSProperties = {
  fontSize: 24,
  fontWeight: 800,
  margin: 0,
  color: "#111827",
};

const tvrtkaMetaStyle: React.CSSProperties = {
  display: "grid",
  gap: 8,
  color: "#4b5563",
  fontSize: 14,
  marginBottom: 20,
};

const tvrtkaActionsStyle: React.CSSProperties = {
  display: "flex",
  gap: 10,
  flexWrap: "wrap",
  marginTop: "auto",
};

const darkLinkStyle: React.CSSProperties = {
  display: "inline-block",
  padding: "10px 14px",
  background: "#111827",
  color: "white",
  borderRadius: 10,
  textDecoration: "none",
  fontWeight: 700,
};

const smallGrayButtonStyle: React.CSSProperties = {
  padding: "10px 14px",
  borderRadius: 10,
  border: "none",
  background: "#9ca3af",
  color: "white",
  fontWeight: 700,
  cursor: "pointer",
};

const smallRedButtonStyle: React.CSSProperties = {
  padding: "10px 14px",
  borderRadius: 10,
  border: "none",
  background: "#dc2626",
  color: "white",
  fontWeight: 700,
  cursor: "pointer",
};