import { prisma } from "@/lib/prisma";

function parseDate(value: unknown): Date | null {
  if (!value) return null;

  const v = String(value).trim();
  if (!v) return null;

  if (v.includes("T")) {
    const d = new Date(v);
    return Number.isNaN(d.getTime()) ? null : d;
  }

  if (/^\d{4}-\d{2}-\d{2}$/.test(v)) {
    const d = new Date(`${v}T00:00:00.000Z`);
    return Number.isNaN(d.getTime()) ? null : d;
  }

  const dots = v.match(/^(\d{1,2})\.(\d{1,2})\.(\d{4})\.?$/);
  if (dots) {
    const [, dd, mm, yyyy] = dots;
    const iso = `${yyyy}-${mm.padStart(2, "0")}-${dd.padStart(2, "0")}T00:00:00.000Z`;
    const d = new Date(iso);
    return Number.isNaN(d.getTime()) ? null : d;
  }

  const d = new Date(v);
  return Number.isNaN(d.getTime()) ? null : d;
}

async function syncPlanerForLijecnicki(input: {
  zapisId: string;
  firmaId: string;
  oib: string;
  vrsta: string | null;
  vrijediDo: Date | null;
  napomena: string | null;
}) {
  const radnik = await prisma.radnik.findFirst({
    where: {
      firmaId: input.firmaId,
      oib: input.oib,
    },
    orderBy: {
      createdAt: "desc",
    },
  });

  const radnikIme = radnik?.ime || input.oib;
  const nazivPlanera = `Liječnički pregled: ${radnikIme}`;

  const postojeci = await prisma.planer.findFirst({
    where: {
      firmaId: input.firmaId,
      tip: "lijecnicki",
      radnikId: radnik?.id ?? null,
      naziv: nazivPlanera,
    },
  });

  if (!input.vrijediDo) {
    if (postojeci) {
      await prisma.planer.delete({
        where: { id: postojeci.id },
      });
    }
    return;
  }

  const payload = {
    firmaId: input.firmaId,
    naziv: nazivPlanera,
    opis:
      input.napomena ||
      `Automatski generirano iz liječničkih pregleda. Vrsta: ${input.vrsta || "liječnički pregled"}.`,
    datum: input.vrijediDo,
    tip: "lijecnicki",
    status: "planirano",
    radnikId: radnik?.id ?? null,
    opremaId: null,
  };

  if (postojeci) {
    await prisma.planer.update({
      where: { id: postojeci.id },
      data: payload,
    });
  } else {
    await prisma.planer.create({
      data: payload,
    });
  }
}

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const firmaId = searchParams.get("firmaId");

    const data = await prisma.lijecnickiPregled.findMany({
      where: firmaId ? { firmaId } : undefined,
      orderBy: [{ vrijediDo: "asc" }, { createdAt: "desc" }],
    });

    return Response.json(data);
  } catch (error) {
    console.error(error);
    return new Response("Ne mogu učitati liječničke preglede.", { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();

    const firmaId = String(body?.firmaId ?? "").trim();
    const oib = String(body?.oib ?? "").trim();
    const datum = parseDate(body?.datum);
    const vrijediDo = parseDate(body?.vrijediDo);
    const vrsta = body?.vrsta ? String(body.vrsta).trim() : null;
    const napomena = body?.napomena ? String(body.napomena).trim() : null;

    if (!firmaId || !oib || !datum || !vrijediDo) {
      return new Response("Nedostaju obavezni podaci.", { status: 400 });
    }

    const zapis = await prisma.lijecnickiPregled.create({
      data: {
        firmaId,
        oib,
        vrsta,
        datum,
        vrijediDo,
        napomena,
      },
    });

    await syncPlanerForLijecnicki({
      zapisId: zapis.id,
      firmaId,
      oib,
      vrsta,
      vrijediDo,
      napomena,
    });

    return Response.json(zapis, { status: 201 });
  } catch (error) {
    console.error(error);
    return new Response("Ne mogu spremiti liječnički pregled.", { status: 500 });
  }
}