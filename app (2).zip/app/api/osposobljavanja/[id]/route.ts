import { prisma } from "@/lib/prisma";

export async function PUT(
  req: Request,
  { params }: { params: { id: string } }
) {
  const body = await req.json();

  const zapis = await prisma.strucnoOsposobljavanje.update({
    where: { id: params.id },
    data: {
      oib: body.oib,
      vrsta: body.vrsta,
      datum: new Date(body.datum),
      vrijediDo: new Date(body.vrijediDo),
      napomena: body.napomena || null,
    },
  });

  return Response.json(zapis);
}

export async function DELETE(
  _req: Request,
  { params }: { params: { id: string } }
) {
  await prisma.strucnoOsposobljavanje.delete({
    where: { id: params.id },
  });

  return Response.json({ ok: true });
}