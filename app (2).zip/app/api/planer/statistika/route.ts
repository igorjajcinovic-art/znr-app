import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

function getTodayStart() {
  const now = new Date();
  return new Date(now.getFullYear(), now.getMonth(), now.getDate());
}

function getSoonEnd(days = 7) {
  const today = getTodayStart();
  const end = new Date(today);
  end.setDate(end.getDate() + days);
  return end;
}

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const firmaIdParam = searchParams.get("firmaId");
    const soonDaysParam = searchParams.get("soonDays");

    if (!firmaIdParam) {
      return NextResponse.json(
        { error: "Nedostaje firmaId" },
        { status: 400 }
      );
    }

    const firmaId = Number(firmaIdParam);
    const soonDays = soonDaysParam ? Number(soonDaysParam) : 7;

    if (Number.isNaN(firmaId)) {
      return NextResponse.json(
        { error: "firmaId mora biti broj" },
        { status: 400 }
      );
    }

    if (Number.isNaN(soonDays) || soonDays < 1) {
      return NextResponse.json(
        { error: "soonDays mora biti pozitivan broj" },
        { status: 400 }
      );
    }

    const today = getTodayStart();
    const soonEnd = getSoonEnd(soonDays);

    /**
     * Pretpostavka:
     * status "zavrseno" znači da stavka više ne ulazi u uskoro/kasni.
     * Ako kod tebe koristiš drugačije nazive statusa, samo proširi ovaj niz.
     */
    const completedStatuses = ["zavrseno"];

    const baseWhere = {
      firmaId,
    };

    const [ukupno, uskoro, kasni] = await Promise.all([
      prisma.planer.count({
        where: baseWhere,
      }),

      prisma.planer.count({
        where: {
          ...baseWhere,
          datum: {
            gte: today,
            lte: soonEnd,
          },
          status: {
            notIn: completedStatuses,
          },
        },
      }),

      prisma.planer.count({
        where: {
          ...baseWhere,
          datum: {
            lt: today,
          },
          status: {
            notIn: completedStatuses,
          },
        },
      }),
    ]);

    return NextResponse.json({
      ukupno,
      uskoro,
      kasni,
      soonDays,
    });
  } catch (error) {
    console.error("Greška kod /api/planer/statistika:", error);

    return NextResponse.json(
      {
        error: "Greška kod dohvaćanja statistike Planera",
      },
      { status: 500 }
    );
  }
}