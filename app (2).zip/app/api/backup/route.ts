import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET() {
  try {
    const tvrtke = await prisma.tvrtka.findMany();
    const radnici = await prisma.radnik.findMany();
    const lijecnicki = await prisma.lijecnickiPregled.findMany();
    const osposobljavanja = await prisma.strucnoOsposobljavanje.findMany();

    return NextResponse.json({
      tvrtke,
      radnici,
      lijecnicki,
      osposobljavanja,
    });
  } catch (err) {
    return new NextResponse("Greška kod backupa", { status: 500 });
  }
}