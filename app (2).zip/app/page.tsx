import Link from "next/link";

export default function HomePage() {
  return (
    <main
      style={{
        minHeight: "100vh",
        background: "#f3f4f6",
        padding: 24,
      }}
    >
      <div style={{ maxWidth: 1100, margin: "0 auto" }}>
        <h1
          style={{
            fontSize: 36,
            fontWeight: 700,
            marginBottom: 24,
          }}
        >
          Evidencija zaštite na radu
        </h1>

        <div
          style={{
            background: "white",
            borderRadius: 16,
            boxShadow: "0 1px 4px rgba(0,0,0,0.08)",
            padding: 24,
          }}
        >
          <h2
            style={{
              fontSize: 24,
              fontWeight: 700,
              marginBottom: 12,
            }}
          >
            Tvrtke
          </h2>

          <p
            style={{
              color: "#6b7280",
              marginBottom: 18,
            }}
          >
            Prvo odaberi tvrtku, pa onda ulaziš u radnike, liječničke preglede i ostale evidencije.
          </p>

          <Link
            href="/tvrtke"
            style={{
              display: "inline-block",
              padding: "10px 16px",
              background: "#111827",
              color: "white",
              borderRadius: 8,
              textDecoration: "none",
            }}
          >
            Otvori tvrtke
          </Link>
        </div>
      </div>
    </main>
  );
}